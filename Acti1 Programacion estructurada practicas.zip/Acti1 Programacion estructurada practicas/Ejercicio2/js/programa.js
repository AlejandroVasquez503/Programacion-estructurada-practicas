console.log("Mi nombre es René Alejandro y tengo 18 años");
alert("¡Hola! Ingrese un numero porfavor");

let numero = prompt("Ingresa un número:");
if (numero > 0) {
    console.log("El número es positivo.");
} else if (numero < 0) {
    console.log("El número es negativo.");
} else {
    console.log("El número es cero.");
}
