console.log("Mi nombre es René Alejandro y tengo 18 años");

alert("¡Hola! ingrese un numero.");
let numero = prompt("Ingresa un número para generar su tabla de multiplicar:");
for (let i = 1; i <= 10; i++) {
    console.log(numero + " x " + i + " = " + numero * i);
}

